
//funcion que ejecuta el proceso
//var calculadora = new Object();
 var Calculadora = {

  init: function() {
	//variables globales
	  var num1 = "";
	  var num2 ="";
		var operador ="";
		var contador ="";
		let decimal;
		let entero;

	  var resultado ="";
  //Declaracion de variables botones
    var resultado = document.getElementById('display');
  	var reset = document.getElementById('on');
    var signo = document.getElementById('sign');
  	var suma = document.getElementById('mas');
    var raiz = document.getElementById('raiz');
  	var resta = document.getElementById('menos');
		var pun = document.getElementById('punto');
		var puns =".";
  	var multiplicacion = document.getElementById('por');
  	var division = document.getElementById('dividido');
  	var igual = document.getElementById('igual');
  	var uno = document.getElementById('1');
  	var dos = document.getElementById('2');
  	var tres = document.getElementById('3');
  	var cuatro = document.getElementById('4');
  	var cinco = document.getElementById('5');
  	var seis = document.getElementById('6');
  	var siete = document.getElementById('7');
  	var ocho = document.getElementById('8');
  	var nueve = document.getElementById('9');
  	var cero = document.getElementById('0');


//tecla on
     reset.addEventListener("mousedown", function () {
     reset.style.transform = "scale(.95, .95)";
     document.getElementById("display").innerHTML ="0";

});
     reset.addEventListener("mouseup", function () {
     reset.setAttribute("style", "transform:scale(1, 1)");

});

//tecla sign
     sign.addEventListener("mousedown", function () {
     sign.style.transform = "scale(.95, .95)";
		 num1 =document.getElementById("display").innerHTML;
		 //
		 var cadena =num1.length;
		 resultado = num1.lastIndexOf("-");

       if (num1 == 0) {

      }else {



			if (cadena>=0 && resultado ==-1){


			 document.getElementById("display").innerHTML ="-" +""+ num1;

			}else if(num1.charAt(num1.length [0])=="-") {

				resultado =num1.substring(1);
				document.getElementById("display").innerHTML = resultado;
			}

			 else{ document.getElementById("display").innerHTML = "-" +""+ num1;}
		 }

});
     sign.addEventListener("mouseup", function () {
     sign.setAttribute("style", "transform:scale(1, 1)");
});

//tecla Raiz
     raiz.addEventListener("mousedown", function () {
     raiz.style.transform = "scale(.95, .95)";

});
     raiz.addEventListener("mouseup", function () {
     raiz.setAttribute("style", "transform:scale(1, 1)");
});

//tecla Division
     division.addEventListener("mousedown", function () {
     division.style.transform = "scale(.95, .95)";
		 operador = document.getElementById("display").innerHTML;

 		if (operador != 0) {
      document.getElementById("display").innerHTML="";
 			contador = 4;


 		}else {
       document.getElementById("display").innerHTML=0;
     }
});
     division.addEventListener("mouseup", function () {
     division.setAttribute("style", "transform:scale(1, 1)");
});

//tecla 7
     siete.addEventListener("mousedown", function () {
     siete.style.transform = "scale(.95, .95)";
		 resultado =document.getElementById("display").innerHTML;
		if (resultado.length <=7) {


		 if ( resultado==0) {

			 document.getElementById("display").innerHTML = siete.id;
	 } else{
		 document.getElementById("display").innerHTML = resultado +""+ siete.id;
	 }
		}


});
    siete.addEventListener("mouseup", function () {
     siete.setAttribute("style", "transform:scale(1, 1)");
});

//tecla 8
     ocho.addEventListener("mousedown", function () {
     ocho.style.transform = "scale(.95, .95)";

		 num1 =document.getElementById("display").innerHTML;
		 if (num1.length <=7) {

		 if (num1.indexOf(".")==1 ) {

			 document.getElementById("display").innerHTML = num1 +""+ ocho.id;

		} else if(num1 == 0) {

			document.getElementById("display").innerHTML = ocho.id;

		}else if (num1!=0) {
			document.getElementById("display").innerHTML = num1 +""+ ocho.id;
		}

	}


});
     ocho.addEventListener("mouseup", function () {
     ocho.setAttribute("style", "transform:scale(1, 1)");


});

//tecla 9
     nueve.addEventListener("mousedown", function () {
     nueve.style.transform = "scale(.95, .95)";
		 num1 =document.getElementById("display").innerHTML;
	 	if (num1.length <=7) {

	 	if (num1.indexOf(".")==1 ) {

	 		document.getElementById("display").innerHTML = num1 +""+ nueve.id;

	  } else if(num1 == 0) {

	 	 document.getElementById("display").innerHTML = nueve.id;

	  }else if (num1!=0) {
	 	 document.getElementById("display").innerHTML = num1 +""+ nueve.id;
	  }

	 }
});
     nueve.addEventListener("mouseup", function () {
     nueve.setAttribute("style", "transform:scale(1, 1)");
});

//tecla por
     por.addEventListener("mousedown", function () {
     por.style.transform = "scale(.95, .95)";
		 operador = document.getElementById("display").innerHTML;
     if (operador != 0) {
       document.getElementById("display").innerHTML="";
  			contador = 3;


  		}else {
        document.getElementById("display").innerHTML=0;
      }


});
     por.addEventListener("mouseup", function () {
     por.setAttribute("style", "transform:scale(1, 1)");
});


//tecla 4
     cuatro.addEventListener("mousedown", function () {
     cuatro.style.transform = "scale(.95, .95)";
		 resultado =document.getElementById("display").innerHTML;
		 num1 =document.getElementById("display").innerHTML;
 		if (num1.length <=7) {

 		if (num1.indexOf(".")==1 ) {

 			document.getElementById("display").innerHTML = num1 +""+ cuatro.id;

 	 } else if(num1 == 0) {

 		 document.getElementById("display").innerHTML = cuatro.id;

 	 }else if (num1!=0) {
 		 document.getElementById("display").innerHTML = num1 +""+ cuatro.id;
 	 }

  }
});
     cuatro.addEventListener("mouseup", function () {
     cuatro.setAttribute("style", "transform:scale(1, 1)");
});

//tecla 5
     cinco.addEventListener("mousedown", function () {
     cinco.style.transform = "scale(.95, .95)";
		 resultado =document.getElementById("display").innerHTML;
		 num1 =document.getElementById("display").innerHTML;
 		if (num1.length <=7) {

 		if (num1.indexOf(".")==1 ) {

 			document.getElementById("display").innerHTML = num1 +""+ cinco.id;

 	 } else if(num1 == 0) {

 		 document.getElementById("display").innerHTML = cinco.id;

 	 }else if (num1!=0) {
 		 document.getElementById("display").innerHTML = num1 +""+ cinco.id;
 	 }

  }

});
     cinco.addEventListener("mouseup", function () {
     cinco.setAttribute("style", "transform:scale(1, 1)");
});

//tecla 6
     seis.addEventListener("mousedown", function () {
     seis.style.transform = "scale(.95, .95)";

		 num1 =document.getElementById("display").innerHTML;
		 if (num1.length <=7) {

     if (num1.indexOf(".")==1 ) {

			 document.getElementById("display").innerHTML = num1 +""+ seis.id;

    } else if(num1 == 0) {

			document.getElementById("display").innerHTML = seis.id;

		}else if (num1!=0) {
			document.getElementById("display").innerHTML = num1 +""+ seis.id;
		}

	}
});
     seis.addEventListener("mouseup", function () {
     seis.setAttribute("style", "transform:scale(1, 1)");
});

//tecla menos
     menos.addEventListener("mousedown", function () {
     menos.style.transform = "scale(.95, .95)";
     operador = document.getElementById("display").innerHTML;
     if (operador != 0) {
       document.getElementById("display").innerHTML="";
  			contador = 2;


  		}else {
        document.getElementById("display").innerHTML=0;
      }
});
     menos.addEventListener("mouseup", function () {
     menos.setAttribute("style", "transform:scale(1, 1)");

});


//tecla 1
     uno.addEventListener("mousedown", function () {
     uno.style.transform = "scale(.95, .95)";

		 num1 =document.getElementById("display").innerHTML;
 		if (num1.length <=7) {

 		if (num1.indexOf(".")==1 ) {

 			document.getElementById("display").innerHTML = num1 +""+ uno.id;

 	 } else if(num1 == 0) {

 		 document.getElementById("display").innerHTML = uno.id;

 	 }else if (num1!=0) {
 		 document.getElementById("display").innerHTML = num1 +""+ uno.id;
 	 }

  }
});
     uno.addEventListener("mouseup", function () {
     uno.setAttribute("style", "transform:scale(1, 1)");
});


//tecla 2
     dos.addEventListener("mousedown", function () {
     dos.style.transform = "scale(.95, .95)";
		 resultado =document.getElementById("display").innerHTML;
		 num1 =document.getElementById("display").innerHTML;
 		if (num1.length <=7) {

 		if (num1.indexOf(".")==1 ) {

 			document.getElementById("display").innerHTML = num1 +""+ dos.id;

 	 } else if(num1 == 0) {

 		 document.getElementById("display").innerHTML = dos.id;

 	 }else if (num1!=0) {
 		 document.getElementById("display").innerHTML = num1 +""+ dos.id;
 	 }

  }

});
     dos.addEventListener("mouseup", function () {
     dos.setAttribute("style", "transform:scale(1, 1)");
});


//tecla 3
     tres.addEventListener("mousedown", function () {
     tres.style.transform = "scale(.95, .95)";
		 resultado =document.getElementById("display").innerHTML;
		if (resultado.length <=7) {


		 if ( resultado==0) {

			 document.getElementById("display").innerHTML = tres.id;
	 } else{
		 document.getElementById("display").innerHTML = resultado +""+ tres.id;
	 }
		}

});
     tres.addEventListener("mouseup", function () {
     tres.setAttribute("style", "transform:scale(1, 1)");
});

//tecla 0
     cero.addEventListener("mousedown", function () {
     cero.style.transform = "scale(.95, .95)";
		 resultado =document.getElementById("display").innerHTML;
		if (resultado.length <=7) {


		 if ( resultado==0) {

			 document.getElementById("display").innerHTML = cero.id;
	 } else{
		 document.getElementById("display").innerHTML = resultado +""+ cero.id;
	 }
		}
});
     cero.addEventListener("mouseup", function () {
     cero.setAttribute("style", "transform:scale(1, 1)");
});

//tecla punto
     pun.addEventListener("mousedown", function () {
     pun.style.transform = "scale(.95, .95)";
		 num1 =document.getElementById("display").innerHTML;
		 //
		 var cadena =num1.length;
		 resultado = num1.lastIndexOf(".");



     if (cadena>=0 && resultado ==-1){


      document.getElementById("display").innerHTML =num1 +""+ ".";

			}else if(num1.charAt(num1.length-1)==".") {}

			 else{ document.getElementById("display").innerHTML =num1 +""+ ".";}

});
     punto.addEventListener("mouseup", function () {
     punto.setAttribute("style", "transform:scale(1, 1)");

});


//tecla igual
     igual.addEventListener("mousedown", function () {
     igual.style.transform = "scale(.95, .95)";
    Igual();

});
     igual.addEventListener("mouseup", function () {
     igual.setAttribute("style", "transform:scale(1, 1)");

});



//tecla mas
    suma.addEventListener("mousedown", function () {
    suma.style.transform = "scale(.95, .95)";
		operador = document.getElementById("display").innerHTML;
    if (operador != 0) {
      document.getElementById("display").innerHTML="";
       contador = 1;


     }else {
       document.getElementById("display").innerHTML=0;
     }


});
     mas.addEventListener("mouseup", function () {
     mas.setAttribute("style", "transform:scale(1, 1)");
});
function Suma(){

	num2 = document.getElementById("display").innerHTML;
	resultado = parseFloat(operador) + parseFloat(num2);
	var num =resultado.toString();
	var tipo = num.indexOf(".");
	arr = num.split(".");


	 entero = parseInt(arr[0]);
	 decimal = parseInt(arr[1]);

	if (tipo !== -1) {

		document.getElementById("display").innerHTML = entero +"."+ decimal;

	}else {
		if (entero.toString().length>"7") {
	       entero.toFixed(6);
		}else{
			document.getElementById("display").innerHTML = entero;
		}
	}
	contador =0;

}
function Resta(){
	num2 = document.getElementById("display").innerHTML;
	resultado = parseFloat(operador) - parseFloat(num2);
	var num =resultado.toString();
	var tipo = num.indexOf(".");
	arr = num.split(".");


	 entero = parseInt(arr[0]);
	 decimal = parseInt(arr[1]);

	if (tipo !== -1) {

		document.getElementById("display").innerHTML = entero +"."+ decimal;

	}else {
		if (entero.toString().length>"7") {
				 entero.toFixed(6);
		}else{
			document.getElementById("display").innerHTML = entero;
		}
	}
	contador =0;



}

function Multiplicar(){
num2 = document.getElementById("display").innerHTML;
resultado = parseFloat(operador) * parseFloat(num2);
var num =resultado.toString();
var tipo = num.indexOf(".");
arr = num.split(".");


 entero = parseInt(arr[0]);
 decimal = parseInt(arr[1]);

if (tipo !== -1) {

	document.getElementById("display").innerHTML = entero +"."+ decimal;

}else {
	if (entero.toString().length>"7") {
       entero.toFixed(6);
	}else{
		document.getElementById("display").innerHTML = entero;
	}
}
contador =0;
}

function Division(){
	num2 = document.getElementById("display").innerHTML;
	resultado = parseFloat(operador) / parseFloat(num2);
	var num =resultado.toString();
	var tipo = num.indexOf(".");
	arr = num.split(".");


	 entero = parseInt(arr[0]);
	 decimal = parseInt(arr[1]);

	if (tipo !== -1) {

		document.getElementById("display").innerHTML = entero +"."+ decimal;

	}else {
		if (entero.toString().length>"7") {
				 entero.toFixed(6);
		}else{
			document.getElementById("display").innerHTML = entero;
		}
	}
	contador =0;


};
function Igual(){
resultado =document.getElementById("display").innerHTML;
	switch (contador) {
		case 0:
			resultado = parseInt(resultado) + parseInt(num2);
			document.getElementById("display").innerHTML =resultado;
			break;
		case 1:
       Suma();
			break;
			case 2:
       Resta();
				break;
				case 3:
        Multiplicar(num1);
					break;
					case 4:
        Division();
						break;
		default:

	}


}
function limpiarDisplay(){
document.getElementById("display").innerHTML = 0;

}
}
}

var calculo = Object.create(Calculadora);
calculo.init();
